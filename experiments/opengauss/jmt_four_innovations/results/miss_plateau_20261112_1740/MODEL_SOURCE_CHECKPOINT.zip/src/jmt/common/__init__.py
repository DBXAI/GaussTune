"""JMT common."""
