# 创新三：收益边界、峰值预算与联合选择

当前实际推荐入口：`recommend_current_five_stages.py --tp-cache-boundary <v2>`。
v2按SB miss的相邻容量边际改善选右端点，并在预测/DP前强制剪除SB>B_high。
`find_b_high()`要求显式SB命中率；旧99%规则已改名为
`find_b_high_legacy_hit_fraction()`，仅保留历史证据兼容。
用户当前目标是最高TP TPS，实际联合目标在 `current_joint.py`；
`objective.select_for_target_tps`是旧达标优先策略，不是当前默认。
上界不是推荐值，例如上界4 GiB仍可选2 GiB。

以下为历史pipeline接口说明，不作为当前实验入口：

`find_b_high/find_b_low/bounded_sb_interval` → SB 采样 → `solve_work_mem_dp`。
DP 输出非支配候选，不是最终全局最优。预算按真实算子峰值语义，而非 ΣWM。
明确的统一目标在 `objective.select_for_target_tps`：TP 达标后最小化 AP 时间。
planner 保持 running query 原 WM 并 FIFO 准入；pipeline 的历史策略保留兼容，不要当默认生产方案。
