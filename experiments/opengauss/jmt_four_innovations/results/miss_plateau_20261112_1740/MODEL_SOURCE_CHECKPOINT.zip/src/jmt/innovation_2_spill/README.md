# 创新二：源码机理驱动的 AP 内存与 spill

纯入口：`ForecastSession(sql,catalog).forecast(blind_plan,work_mem_mib)`。
没有 DB 连接，没有目标执行，没有默认事实表采样。
逻辑临时读写、算子模式、类型/基数证据、未知状态显式返回；未知总量不是零。
旧校准 model_bundle 和新实验 ap_plan_model 分开，不能替换名字就接入自动推荐。
